
JS++ Integration for Visual Studio Code
---

This plugin provides JS++ integration for Visual Studio Code.

Installation
---
1. Copy the "jspp" folder to the VS Code "extensions" folder. This is usually located at:

   - **On Windows**: `"%programfiles%\Microsoft VS Code\resources\app\extensions\"`
   - **On MacOS (OS X)**: `~/.vscode/extensions/`

2. Restart Visual Studio Code.
